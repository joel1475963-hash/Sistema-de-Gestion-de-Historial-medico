<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="contenedor-principal">
    <h2>Datos del paciente</h2>

    <p>Cedula: <?php echo e($paciente->ci); ?></p>
    <p>Nombre: <?php echo e($paciente->nombre); ?></p>
    <p>Comentario: <?php echo e($paciente->comentario); ?></p>

    <h3>Pacientes registrados</h3>
    <p><?php echo e($cantidadPacientes); ?> de 10 pacientes</p>

    <a class="boton1" href="<?php echo e(url('/inicio')); ?>">Volver al inicio</a>
</main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_gestion_historial_medico\Laravel-Sistema_Medico\Sistema-Medico\resources\views/procesar.blade.php ENDPATH**/ ?>
<footer class="pie-pagina" id="contacto">
        <p><strong>Correo Electronico:</strong> joel.huancal@uab.edu.bo</p>
        <p>&copy; Joel Huanca Laura. Todos los derechos reservados.</p>
    </footer>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistema_gestion_historial_medico\Laravel-Sistema_Medico\Sistema-Medico\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
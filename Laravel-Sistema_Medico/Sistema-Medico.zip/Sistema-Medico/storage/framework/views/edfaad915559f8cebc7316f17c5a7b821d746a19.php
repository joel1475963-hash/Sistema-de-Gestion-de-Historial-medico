<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="contenedor-principal">
<h2>Pacientes registrados</h2>
<h2>Bienvenido <?php echo e(session('nombreUsu')); ?></h2>
<?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>Nombre: <?php echo e($paciente->nombre); ?></p>
    <p>Comentario: <?php echo e($paciente->comentario); ?></p>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_gestion_historial_medico\Laravel-Sistema_Medico\Sistema-Medico\resources\views/visualizar-usuario.blade.php ENDPATH**/ ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="contenedor-principal">
    <div class="div-centrado2">
    <a class="boton1" href="<?php echo e(url('usuario')); ?>">Inicio sesion como usuario</a>
    <a class="boton1" href="<?php echo e(url('paciente')); ?>">Iniciar sesion como paciente</a>
    </div>
</main>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_gestion_historial_medico\Laravel-Sistema_Medico\Sistema-Medico\resources\views/login.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">
    <title>Sistema de Gestión de Historial Medico</title>
</head>
<body>
    <header id="inicio">
        <h1 class="titulo">Sistema web de Gestion de historial Medico</h1>
    </header>
    <div class="div-centrado">
        <button id="btnModo" class="btn-modo">Modo Noche</button>
    </div>
    <nav class="navbar">
        <h3 class="titulo-menu">Menú</h3>
    
        <button
            id="btnMenu"
            type="button"
            class="btn-hamburguesa"
            aria-label="Abrir menú"
            aria-expanded="false"
        >
            ☰
        </button>
    
        <ul class="menu" id="menuPrincipal">
            <li><a href="<?php echo e(asset('inicio')); ?>#inicio">Inicio</a></li>
            <li><a href="<?php echo e(asset('inicio')); ?>#proposito">Propósito</a></li>
            <li><a href="<?php echo e(asset('inicio')); ?>#reserva">Reservar ficha</a></li>
            <li><a href="<?php echo e(asset('inicio')); ?>#contacto">Contacto</a></li>
            <li><a href="<?php echo e(url('/cantidad-pacientes')); ?>">Pacientes registrados</a></li>
            <?php if(session()->has('usuario_id')): ?>
            <li><a href="<?php echo e(url('/visualizar-usuario')); ?>">Ver pacientes</a></li>
                <li>
                    <form action="<?php echo e(url('/cerrar-sesion')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="enlace-menu" type="submit">Cerrar sesion</button>
                    </form>
                </li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(url('/login')); ?>">Iniciar sesion</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

<?php /**PATH C:\xampp\htdocs\sistema_gestion_historial_medico\Laravel-Sistema_Medico\Sistema-Medico\resources\views/layouts/header.blade.php ENDPATH**/ ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="contenedor-principal">
<div class="div-centrado">
<h3>Pacientes registrados</h3>
<?php if(session('succeful')): ?>
    <p class="registrado"><?php echo e(session('succeful')); ?></p>
<?php endif; ?>
    <p><?php echo e($cantidadPacientes); ?> de 10 pacientes</p>
        
    <a class="boton1" href="<?php echo e(url('/inicio')); ?>">Volver al inicio</a>
</div>
</main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_gestion_historial_medico\Laravel-Sistema_Medico\Sistema-Medico\resources\views/cantidad-pacientes.blade.php ENDPATH**/ ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="contenedor-principal">
    <form action="<?php echo e(url('/validar-usuario')); ?>" method="POST" class="formulario" id="formulario1" novalidate>
        <?php echo csrf_field(); ?>

        <h2>Inicio de sesion</h2>

        <div class="campo">
            <label for="nombreUsu">Nombre de usuario</label>
            <input type="text" id="nombreUsu" name="nombreUsu" required>
        </div>

        <div class="campo">
            <label for="contrasena">Contraseña</label>
            <input type="password" id="contrasena" name="contrasena" required>
        </div>

        <button type="submit" class="boton1">Iniciar sesion</button>
        <p id="errorPedido" class="aviso">error</p>
        <?php if(session('mensaje')): ?>
        <p id="errorPedido" class="error-dato"><?php echo e(session('mensaje')); ?></p>
        <?php endif; ?>
    </form>
</main>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_gestion_historial_medico\Laravel-Sistema_Medico\Sistema-Medico\resources\views/usuario.blade.php ENDPATH**/ ?>